# Zu Christmas

"Zu Christmas" is a Bootstrap landing page for the Holiday season, made by ZuThemes.com.

## Download & Demo

* [Download](http://www.zuthemes.com/freebies/) - Free Download
* [Theme Demo Here](http://clubthemes.com/demo/zuchristmas/) - Theme Demo

## Getting Started

Some basic things before you start.

### Requirements

And editor such as Notepad++ (free) is needed to edit template's files.

### Set Contact Form

Open contact.php and modify line 23. Replace the e-mail address with the one you wish to use to receive messages via website. Edit line 28 (subject).

## Built With

* [Bootstrap](http://www.dropwizard.io/1.0.2/docs/) - The web framework used
* [Icons](http://www.iconarchive.com/artist/stevelianardo.html) - Flat Icon
* [Clipart](http://cliparting.com/free-christmas-clip-art-113/) - Christmas Clipart

## Authors

* [ZuThemes](https://www.zuthemes.com)

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details. License and Copyright Notice ZuThemes.com. You may remove attribution link for a small donation.
